
import { getLocaleDateFormat } from '@angular/common';
export class Payment {

    paymentId:number=0;
    policyId:number=0;
    userId:number=0;
    billdate:string='';
    dueDate:string='';
    fine:number=0.0;
    paymentAmount:number=0.0;
    paymentType:string='';
    status:string='';
}
