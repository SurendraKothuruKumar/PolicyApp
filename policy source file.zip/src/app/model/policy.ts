export class Policy {

    policyId:number=0;
	policyName:string='';
	policyDesc:string='';
	policyType:string='';
	sumAssured:number=0.0;
	premium:number=0.0;
	duration:number=0;
	companyName:string='';
}
