export class User {
    userId:number=0;
    firstName:string="";
    lastName:string="";
    age:number=0;
    mobileNumber:string="";
    gender:string="";
    userName:string="";
    password:string="";
    dateOfBirth:string="";
}
