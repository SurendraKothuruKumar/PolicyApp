import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Policy } from 'src/app/model/policy';
import { PolicyService } from 'src/app/service/policy.service';

@Component({
  selector: 'app-userhome',
  templateUrl: './userhome.component.html',
  styleUrls: ['./userhome.component.css']
})
export class UserhomeComponent implements OnInit {

  uname:any;
  userId:any;
  policyType:any;
  loading: boolean | undefined;
  
  submitted=false;
  ngOnInit(): void {
    this.uname= sessionStorage.getItem('userName');
  }

  onSubmit(){
  
   this.userId= sessionStorage.getItem('userId');
  this.search();
  }
  
  policyList: any;
  policytemp: any;
  PolicytempList: Policy[] = [];
  policy:Policy = new Policy;
  constructor(private policyserv: PolicyService, private router: Router) {}
  search(){
    this.policyserv.getPolicy(this.policyType)
      .subscribe((data: any) => {
        this.policyList = data;
        this.PolicytempList = this.policyList;
        this.submitted=true;
        console.log(this.PolicytempList);
        this.loading = false;
      }, ((error: any) => {
        console.log(error)
        this.loading = true;
        return null;
      }), () => {
        this.loading = false;
      });
  
    }
    isUserLoggedIn() {
      let user = sessionStorage.getItem('userName');
      this.uname=user;
      return !(user === null)
    }

}
