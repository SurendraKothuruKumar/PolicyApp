import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Payment } from 'src/app/model/payment';
import { Policy } from 'src/app/model/policy';
import { PolicyService } from 'src/app/service/policy.service';
import { User } from 'src/app/user';

@Component({
  selector: 'app-paypolicy',
  templateUrl: './paypolicy.component.html',
  styleUrls: ['./paypolicy.component.css']
})
export class PaypolicyComponent implements OnInit {

  userId:any;
  bd:string='';
  dd:string='';
  policyId: any;
  cpolicyId: any;
  policy:Policy = new Policy;
  user:User = new User;
  payment:Payment | undefined ;
  loading: boolean | undefined;
  paymentAmount: number | undefined;
  date: Date = new Date();
  ddate: Date = new Date();
  constructor(private activatedRoute: ActivatedRoute,private formBuilder: FormBuilder, private policyservice: PolicyService, private router: Router) { 
    this.policyId=activatedRoute.snapshot.paramMap.get("policyId");
    this.userId= sessionStorage.getItem('userId');
    sessionStorage.setItem('cpolicyId',this.policyId);
    this.date.setDate(this.date.getDate());
    this.date.setHours(this.date.getHours());
    this.bd=this.date.toDateString();
    let datePipe: DatePipe = new DatePipe('en-US');
    console.log(datePipe.transform(this.date, 'short'));
 
    this.ddate.setDate(this.date.getDate()+1);
    this.dd=this.ddate.toDateString();

    this.policyservice.getUserById(this.userId)
    .subscribe((data: any) => {
      this.user = data;
      console.log(this.user);
      this.loading = false;
    }, ((error: any) => {
      console.log(error)
      this.loading = true;
      return null;
    }), () => {
      this.loading = false;
    });
    
    this.policyservice.getPolicyById(this.policyId)
      .subscribe((data: any) => {
        this.policy = data;
        this.paymentAmount=this.policy.premium;
        console.log(this.policy);
        this.loading = false;
        this.payForm = this.formBuilder.group(
          {
      
          policyId:[ this.policyId,Validators.compose([Validators.required])],
          userId:[this.userId, Validators.compose([Validators.required])],
          billdate:[Validators.compose([Validators.required])],
          dueDate:[  Validators.compose([Validators.required])],
          paymentAmount:[ this.policy.premium, Validators.compose([Validators.required])],
          fine:[ '0.0',Validators.compose([Validators.required])], 
          status:['paid',Validators.compose([Validators.required])], 
          paymentType:[Validators.compose([Validators.required])], 
          }
          )
      }, ((error: any) => {
        console.log(error)
        this.loading = true;
        return null;
      }), () => {
        this.loading = false;
      });
     
     

  }

  
  payForm = this.formBuilder.group(
    {
    
    policyId:[this.policy.policyId, Validators.compose([Validators.required])],
    userId:['', Validators.compose([Validators.required])],
    billdate:[  Validators.compose([Validators.required])],
    dueDate:[  Validators.compose([Validators.required])],
    paymentAmount:[  this.policy.premium,Validators.compose([Validators.required])],
    fine:[ '',Validators.compose([Validators.required])],
    status:['paid',Validators.compose([Validators.required])], 
    paymentType:[Validators.compose([Validators.required])], 
    }
    );


    onSubmit() {
    if (!this.payForm.invalid) {
    this.policyservice.addPayment(this.payForm.getRawValue(),this.policyId,this.userId).subscribe((data: any) => { //success
      this.payment=data;
    alert("Payment is successfully created.");
    this.router.navigateByUrl("/userhome");
    }, ((error: any) => { // error
    alert("Error in creating Payment .");
    console.log(error)
    return null;
    }), () => { //complete
    });
    }
    }
    
  ngOnInit(): void {
  }


}
