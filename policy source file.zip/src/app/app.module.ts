import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { PaypolicyComponent } from './user/paypolicy/paypolicy.component';
import { UserheadComponent } from './user/userhead/userhead.component';
import { UserhomeComponent } from './user/userhome/userhome.component';
import { AddpolicyComponent } from './admin/addpolicy/addpolicy.component';
import { AdminhomeComponent } from './admin/adminhome/adminhome.component';
import { EditpolicyComponent } from './admin/editpolicy/editpolicy.component';
import { PolicylistComponent } from './admin/policylist/policylist.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    HeaderComponent,
    HomeComponent,
    LoginComponent,
    RegistrationComponent,
    PaypolicyComponent,
    UserheadComponent,
    UserhomeComponent,
    AddpolicyComponent,
    AdminhomeComponent,
    EditpolicyComponent,
    PolicylistComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
