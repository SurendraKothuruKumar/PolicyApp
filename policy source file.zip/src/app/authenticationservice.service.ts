import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationserviceService {

  cuser:User=new User();
  uname:any;
 
  constructor(private http:HttpClient) { }

  private baseUrl ='http://localhost:1010/login';
  
getuser()
{
  return this.cuser;
}


saveUser(data:any)
{
   console.log(data);
   this.cuser=data;
   console.log(data.firstName);
   sessionStorage.setItem('userName',data.firstName);
   sessionStorage.setItem('userId',data.userId);
}

isUserLoggedIn() {
  let user = sessionStorage.getItem('userName')
  this.uname=user;
  return !(user === null)
}

loginUser(user:any) : Observable<any>
{
  console.log(user);
  const urlstr=this.baseUrl​​​​​​​​+"/"+​​​​​user;
  return this.http.post(this.baseUrl,user);


}

logout()
{
  sessionStorage.removeItem('userName');
}
}
