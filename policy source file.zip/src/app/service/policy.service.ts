import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Payment } from '../model/payment';
import { Policy } from '../model/policy';
import { User } from '../user';

@Injectable({
  providedIn: 'root'
})
export class PolicyService {

  
  
  addPayment(payment: Payment,policyId:number,userId: any) {
    return this.http.post<Observable<Payment>>('http://localhost:3030/createPayment',payment);
  }
  getUserById(userId: any) {
    return  this.http.get<Observable<User>>('http://localhost:1010/user?id='+ userId);
  }
  getPolicy(policyType: string) {
  return  this.http.get<Observable<Policy>>('http://localhost:2020/searchPolicy?policyType='+ policyType);
  }

  
  addPolicy(pol: Policy) {
    return this.http.post<Observable<Policy>>('http://localhost:2020/createPolicy',pol);
    }
    
    getAllPolicy()
    {
      return this.http.get<Observable<Policy>>('http://localhost:2020/Policys');
    }
    
    getPolicyById(policyId:number)
    {
      return this.http.get<Observable<Policy>>('http://localhost:2020/Policy?id='+policyId);
    }

    updatePolicy(policy:Policy){
      console.log(policy);
  
      return this.http.put<Observable<Policy>>('http://localhost:2020/Policy',policy);
    }





    constructor(private http:HttpClient) { }
    
}
