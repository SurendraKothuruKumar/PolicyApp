import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PolicyService } from 'src/app/service/policy.service';

@Component({
  selector: 'app-addpolicy',
  templateUrl: './addpolicy.component.html',
  styleUrls: ['./addpolicy.component.css']
})
export class AddpolicyComponent implements OnInit {

  message!: string;
  policyList: string[] = ['Healthcare','Lic', 'Vehicle', 'Home' , 'Property'];


constructor(private formBuilder: FormBuilder, private Policyservice: PolicyService, private router: Router) { }



policyForm = this.formBuilder.group(
{

policyId:['0', Validators.compose([Validators.required])],
policyName:['', Validators.compose([Validators.required])],
policyDesc:['', Validators.compose([Validators.required])],
policyType:['', Validators.compose([Validators.required])],
sumAssured:['', Validators.compose([Validators.required])],
premium:['', Validators.compose([Validators.required])],
duration:['', Validators.compose([Validators.required])],
companyName:['', Validators.compose([Validators.required])],
}

)
onSubmit() {
if (!this.policyForm.invalid) {
this.Policyservice.addPolicy(this.policyForm.getRawValue()).subscribe((data: any) => { //success
alert("Policy is successfully created.");
this.router.navigateByUrl("/policylist");
}, ((error: any) => { // error
alert("Error in creating employee details.");
console.log(error)
return null;
}), () => { //complete
});
}
}



ngOnInit(): void {
}


}
