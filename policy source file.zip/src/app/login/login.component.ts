import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../user';
import { AuthenticationserviceService } from '../authenticationservice.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  registration=sessionStorage.getItem("key");
  user:User=new User();
  message='';
  constructor(private loginservice:AuthenticationserviceService, private router:Router) { }


  ngOnInit(): void {
  }

  loginUser()
   {
    if(this.user.userName=="admin@1234" && this.user.password=="admin"){
      console.log(this.user);
      this.router.navigate(['/policylist']);
       localStorage.setItem('user',this.user.userName);
    }else {
     var a = this.user
    this.loginservice.loginUser(this.user)
     .subscribe(
       data => {
         console.log(data);
         this.save(data)
         sessionStorage.removeItem("key")
         this.router.navigate(['/userhome']);
      },
      error => {
        console.log("exception occured");
       this.message="Enter  valid userid and password";
     });

       }
      }
       save(data: { lastName: string; })
       {
         this.loginservice.saveUser(data);
       }
  goToRegister()
  {
    this.router.navigate(['register']);
  }
  

}
